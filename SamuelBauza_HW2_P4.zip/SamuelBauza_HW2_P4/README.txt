Required Libraries:

Python 2.7.14

numpy
glob
Queue


running code:
place input file in /src
e.x. SamuelBauza_HW2_P4/src/input_1.txt
place coord_file in /src
e.x. SamuelBauza_HW_P4/src/input_1

NOTE: The expected format is "input_*.txt" and "coords_*.txt",
This format must be matched and each input must be paired with a coords.

The output will be the results of each of these files in order (if numbers are skipped, so is the output line)

simply go to SamuelBauza_HW2_P4/
> python main.py

output will be output to output_costs.txt and output_numiters.txt in same folder as main.py